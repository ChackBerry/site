INSERT INTO `users` (`id`, `username`, `password`, `email`, `since`, `last_time_active`, `level`, `group_id`, `send_notifications`, `name`, `birthday`, `description`, `settings`, `homepage`, `image`, `country_id`) VALUES

(1, 'admin', '1 $2a$10$ze.r64Pv1E.CTHUNFpFkVuqxuYlbj00aqqeRDd.kumCTIVtkZ/Q8C', 'admin@fakemail.com', '2013-04-07 12:15:16', 0, 1, 1, 1, '', NULL, '', '', '', '', NULL),
(2, 'corpus_maintainer', '1 $2a$10$HiIXBuvKbZkPOJ3NNegnyO0tEXzI8Q7/.elZyicSbx3b4Q9y3WsRS', 'corpus_maintainer@fakemail.com', '2013-04-07 12:15:50', 0, 1, 2, 1, '', NULL, '', '', '', '', NULL),
(3, 'advanced_contributor', '1 $2a$10$3jg3N9/ig6LTRumZPGPBiexEXFQ/5egPjBh3X/tuuU5R5H2kRX5em', 'advanced_contributor@fakemail.com', '2013-04-07 12:16:37', 0, 1, 3, 1, '', NULL, '', '', '', '', NULL),
(4, 'contributor', '1 $2a$10$lGq/QSz3nwHsDAHubtPC7ebT2dnpVTtcSWCV1LJ/vhOwNuJp3Jxay', 'contributor@fakemail.com', '2013-04-07 12:17:02', 0, 1, 4, 1, '', NULL, '', '', '', '', NULL),
(5, 'inactive', '1 $2a$10$vCE03mwxDuuhISbs9mRnTekuwqPrnTfLjHLoH0zGBg53JE1Z3hl/q', 'inactive@fakemail.com', '2013-04-07 12:17:29', 0, 1, 5, 1, '', NULL, '', '', '', '', NULL),
(6, 'spammer', '1 $2a$10$x68Xtpx56iQubb0LHZN/3ez8auzxe3EnOj8GfY7Xn2DIKjpJIBEry', 'spammer@fakemail.com', '2013-04-07 12:17:54', 0, 1, 6, 1, '', NULL, '', '', '', '', NULL);