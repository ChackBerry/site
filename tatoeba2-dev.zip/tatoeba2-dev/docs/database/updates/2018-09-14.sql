ALTER TABLE sentences CHANGE license license enum('CC BY 2.0 FR', 'CC0 1.0') DEFAULT NULL;
