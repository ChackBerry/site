ALTER TABLE sentences_sentences_lists
  ADD KEY `sentences_list_id` (`sentences_list_id`),
  ADD KEY `sentence_id` (`sentence_id`);
