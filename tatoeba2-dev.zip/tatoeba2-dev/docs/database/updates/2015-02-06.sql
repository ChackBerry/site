ALTER TABLE wall CHANGE owner owner int(11) DEFAULT NULL;
