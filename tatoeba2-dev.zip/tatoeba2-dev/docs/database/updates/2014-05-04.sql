ALTER TABLE langStats MODIFY lang varchar(4) NULL;
