ALTER TABLE `favorites_users` ADD id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST;
ALTER TABLE `favorites_users` ADD `created` datetime DEFAULT NULL;