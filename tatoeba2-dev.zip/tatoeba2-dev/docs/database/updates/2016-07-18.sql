ALTER TABLE `users` MODIFY `birthday` DATE;
