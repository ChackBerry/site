CREATE INDEX dedup_idx on sentences (text, lang);
