ALTER TABLE `sentences_sentences_lists` ADD id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST;
ALTER TABLE `sentences_sentences_lists` ADD `created` datetime DEFAULT NULL;