DROP TABLE `countries`;
