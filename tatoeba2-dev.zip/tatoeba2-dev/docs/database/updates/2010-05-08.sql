ALTER TABLE `sentence_annotations` 
ADD `modified` DATETIME NOT NULL ,
ADD `user_id` INT UNSIGNED NOT NULL;