ALTER TABLE private_messages CHANGE COLUMN isnonread isnonread BOOLEAN NOT NULL DEFAULT '1';
