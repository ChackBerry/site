#!/usr/bin/env python3

if __name__ == "__main__":
   print('This script is obsolete. Please use ./tools/update-translations.sh instead.')
