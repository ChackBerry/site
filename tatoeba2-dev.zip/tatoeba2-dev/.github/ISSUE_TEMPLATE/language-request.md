---
name: Language request
about: Add a new language on Tatoeba
title: ''
labels: lang-request
assignees: 

---

* Language name: 
* Language info: 
* ISO 639-3 code: 
* Public List: 
* Icon: 
* Requested by:
