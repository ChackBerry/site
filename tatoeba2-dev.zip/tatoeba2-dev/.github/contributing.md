Welcome to the Tatoeba repository!

If you are interested in contributing to this project as a developer, please read [our article](https://github.com/Tatoeba/tatoeba2/wiki/Contributing-as-a-developer) about it before you start coding anything.

Before submitting an issue or a pull request, please read our guidelines:

* [Guidelines for submitting issues](https://github.com/Tatoeba/tatoeba2/wiki/Guidelines-for-submitting-issues)
* [Guidelines for submitting pull requests](https://github.com/Tatoeba/tatoeba2/wiki/Guidelines-for-submitting-pull-requests)

Thank you!
