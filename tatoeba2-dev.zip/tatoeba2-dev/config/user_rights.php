<?php
use App\Model\Entity\User;

$config = [
    'user_rights' => [
    ]
];
